//
//  NavController.swift
//  mannersStuff
//
//  Created by Benavidez, Amanda on 4/15/16.
//  Copyright © 2016 Benavidez, Amanda. All rights reserved.
//

import Cocoa

class NavController: UINavigationController {

}
