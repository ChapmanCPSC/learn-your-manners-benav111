//
//  ContentController.swift
//  mannersStuff
//
//  Created by Benavidez, Amanda on 4/15/16.
//  Copyright © 2016 Benavidez, Amanda. All rights reserved.
//

import UIKit

class ContentController: UIViewController {
    
    var content: Contents!
    
    @IBOutlet weak var nameLabel: UILabel!
    

    @IBOutlet weak var contentDescription: UITextView!
    
    @IBOutlet weak var contentImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //gets info for screen
        nameLabel.text = content.name
        contentImage.image = content.setImage(content.imageName)
        contentDescription.text =  content.description
        self.automaticallyAdjustsScrollViewInsets = false 
    }
    
//    @IBAction func backPressed(sender: AnyObject) {
//        
//        self.dismissViewControllerAnimated(true, completion: nil)
//        
//    }
    
    @IBAction func backPressed(sender: AnyObject) {
        //goes back
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    
}