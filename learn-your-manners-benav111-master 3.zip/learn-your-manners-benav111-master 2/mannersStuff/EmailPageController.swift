//
//  EmailPageController.swift
//  mannersStuff
//
//  Created by Benavidez, Amanda on 4/25/16.
//  Copyright © 2016 Benavidez, Amanda. All rights reserved.
//

import UIKit

class EmailPageController: UIViewController {
    
    
    @IBOutlet weak var emailTextBox: UITextField!
    
    @IBOutlet weak var emailMessage: UILabel!
    @IBAction func backPressed(sender: AnyObject) {//goes back
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    
    
    @IBAction func setEmail(sender: AnyObject) {
        //sets the email sender to the email entered
        let userDefaults = NSUserDefaults.standardUserDefaults()
        
        if(emailTextBox.text != "" && self.checkEmail(emailTextBox.text!))
        {//set email if its not empty
            userDefaults.setValue(emailTextBox.text, forKey: "user_email")
            emailMessage.text = "Email Added!"
            emailTextBox.text  = ""
        }
        else
        {
            emailTextBox.text  = ""
            emailMessage.text = "Incorrect email!!"
        }
        
    }
    //inspo taken from http://stackoverflow.com/questions/25471114/how-to-validate-an-e-mail-address-in-swift
    func checkEmail(email:String) -> Bool {
        //sets format acceptable for emails and returns if the email entered matches the format
        let emailPredicate = NSPredicate(format:"SELF MATCHES %@", "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}")
        return emailPredicate.evaluateWithObject(email)
        
    }
}