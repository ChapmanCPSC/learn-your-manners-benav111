//
//  ViewController.swift
//  mannersStuff
//
//  Created by Benavidez, Amanda on 4/15/16.
//  Copyright © 2016 Benavidez, Amanda. All rights reserved.
//

import UIKit
import MessageUI

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, MFMailComposeViewControllerDelegate {

    @IBOutlet weak var sendSummaryButton: UIButton!
    @IBOutlet weak var infoTable: UITableView!
    
    let mailViewController = MFMailComposeViewController()
    //Array of stuff for table cells
    let content: [Contents] = [
        Contents(name: "The Force", imageName: "force", description: "The Force was an energy field that connected all living things in the galaxy. The power of the Force could be used by individuals who were sensitive to it, a power that was tapped through the midi-chlorians. The Force had many alternate names. The Living Force represented the energies of all living things, and those energies were fed into the Cosmic Force that bound the galaxy together and communicated to individuals through the midi-chlorians. The two main practitioners of the Force's power were the Jedi Order and the Sith."),
        Contents(name: "The Light", imageName: "light", description: "The light side of the Force was an aspect of the Force. The Light Side of the Force was aligned with calmness and was used for knowledge and defense. The Jedi were a major practitioner of the light side, and were the mortal enemies of the Sith, which followed the dark side of the Force. The light Side of the Force was primarily used for defensive abilities as opposed to aggressive ones. Those who used the light Side could use general Force powers such as Telekinesis and specific Light side powers such as coming back as a Force Ghost."),
        Contents(name: "The Dark", imageName: "dark", description: "The dark side of the Force, called Bogan or Boga by ancient Force-sensitives on Tython, was an aspect of the Force. Those who used the dark side were known as either Darksiders, Dark Side Adepts, or Dark Jedi when unaffiliated with a dark side organization such as the Sith. Unlike the Jedi, who were famous for using the light side of the Force, darksiders drew power from raw emotions and feelings such as anger, hatred, greed, jealousy, fear, aggression, megalomania, and unrestrained passion. Although Jedi were taught to follow the light side of the Force, the dark side was considered seductive and a Jedi had to maintain vigilance in order to avoid falling to the dark side.Anakin Skywalker was a powerful Jedi who, partly through the machinations of the Sith Lord Sidious, fell from the light side and began practicing the dark side.[6] Even a Jedi raised in the traditions of the Jedi Order from birth could quickly be corrupted by the lure of the dark side in certain situations. Despite this, while the Jedi often described the dark side as a 'quick and easy path,' drawing upon the power of the dark side did not necessarily come with ease or without cost to those who were not used to drawing upon feelings such as hatred and who possessed strong compassion."),
        Contents(name: "The Jedi", imageName: "jedi", description: "A Jedi was a Force-sensitive individual, most often a member of the Jedi Order, who studied, served, and used the mystical energies of the Force; usually, the light side of the Force. The weapon of a Jedi was the lightsaber, a blade made of pure energy. Jedi fought for peace and justice in the Galactic Republic, usually against their mortal enemy: the Sith, who studied the dark side of the Force. The Jedi were of ancient origins, having been present in the galaxy for over one thousand generations. There were ten thousand Jedi in the galaxy before the Clone Wars.At the end of the war, however, they were all but destroyed by the Sith during and after the execution of Order 66, leaving very few Jedi survivors until there was only one known living Jedi, Luke Skywalker, at the end of the Galactic Civil War."),
        Contents(name: "The Sith", imageName: "sith", description: "The Sith, collectively known as the Sith Order, were an order of Force users who utilized the dark side of the Force in an effort to gain power over the galaxy. The Sith were the ancient enemies of the Jedi Order and fought numerous wars with them for thousands of years. Formed thousands of years prior to the Clone Wars, the Sith were the ancient enemies of the Jedi Order. Established by an unknown rogue Jedi, the Sith sought further knowledge and power through learning the dark side of the Force. Eventually, this Jedi was able to amass a sizable following, all of which adhered to this new philosophy that embraced the dark side. This schism in the Jedi Order led to an event known as the Hundred-Year Darkness, in which the Jedi and newly founded Sith Order, once brothers and sisters in the force, fought against one another for power. The civil war ended in the defeat of the Sith, who fled from known space. Unbeknownst to the Jedi however, the Sith settled on Moraband, a world of red sands, where they rebuilt in secret to wait for another chance to strike."),
        Contents(name: "The Rebel Alliance", imageName: "rebel", description: "The Alliance to Restore the Republic, also known as the Alliance to Restore Freedom to the Galaxy, the Rebel Alliance or simply Alliance and, informally, as the Rebellion, was a loose alliance of planetary, system, and sector-level insurrectionist factions. Members of the Rebellion were known as 'Rebels,' 'Rebs,' or 'Rebel Scum' by stormtroopers and other Imperials. They were generally united in common cause, against a common enemy in the form of the Galactic Empire. In order to achieve their primary goal in restoring the former Galactic Republic, the Alliance aimed to remove Emperor Palpatine from power, and his hegemonic New Order from the galaxy."),
        Contents(name: "The First Order", imageName: "first", description: "The First Order, also simply known as the Order, was a military and political organization that was active approximately thirty years after the Battle of Endor. Inspired by the principles of the Galactic Empire, the First Order would briefly inhabit a wing of New Republic politics until tensions became intolerable. Fully seceding into the galaxies vast Unknown Regions, it would plot its ascension as a galactic superpower, and thirty years after Endor, fought against both the Resistance and the Republic for control of the galaxy."),
        Contents(name: "The Republic", imageName: "republic", description: "The Galactic Republic was the ruling government of the galaxy that existed for more than 25 thousand years, until the establishment of the first Galactic Empire in 19 BBY. Throughout its existence, the state was commonly known as the Republic. In the post-Republic era and beyond, it was remembered as the Old Republic; it was also rarely known as the First Galactic Republic. At times, the term Old Order was used to describe the Republic.")
        ]
    var checked = [Bool](count: 8, repeatedValue: false)
    override func viewDidLoad() {
        super.viewDidLoad()
        self.infoTable.delegate = self
        self.infoTable.dataSource = self
        self.mailViewController.mailComposeDelegate = self
        
          }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidAppear(animated: Bool) {
        let userDefaults = NSUserDefaults.standardUserDefaults()
        let userEmail = userDefaults.stringForKey("user_email")
        
        //hide button if no email entered
        if (userEmail != "")
        {
            sendSummaryButton.hidden = false
        }
        else
        {
            sendSummaryButton.hidden = true
        }
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {//gets the number of rows the table should have
        return self.content.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {//adds content to cells
        //gets info from content array
        let  cellInfo = self.content[indexPath.row]
        //adds the cell name
        let myCell = UITableViewCell()
        myCell.textLabel!.text = cellInfo.name
        
        //adds check mark if its been selected before
        if checked[indexPath.row]
        {
            myCell.accessoryType = .Checkmark
        }
        
        return myCell
    }
    
     func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath)
     {//once clicked open corresponding page
        
        //add a checkmark for selected row
        if let cell = tableView.cellForRowAtIndexPath(indexPath) {
            cell.accessoryType = .Checkmark
            checked[indexPath.row] = true
        }
        
        
        tableView.deselectRowAtIndexPath(indexPath, animated: false)
        //instantiates nav view controller
        let navigationVC = self.storyboard!.instantiateViewControllerWithIdentifier("nav_controller") as! UINavigationController
        //instantiates content conroller
        let contentVC = navigationVC.viewControllers[0] as! ContentController
        contentVC.content = self.content[indexPath.row]
        
        self.presentViewController(navigationVC, animated: true, completion: nil)
    }
    
    //opens settings page
    @IBAction func settingsPressed(sender: AnyObject) {
        let navigationVC = self.storyboard!.instantiateViewControllerWithIdentifier("nav2_controller") as! UINavigationController
        self.presentViewController(navigationVC, animated: true, completion: nil)

    }
    
    //help taken from: https://developer.apple.com/library/ios/documentation/MessageUI/Reference/MFMailComposeViewController_class/#//apple_ref/occ/clm/MFMailComposeViewController/canSendMail
    //https://www.hackingwithswift.com/example-code/uikit/how-to-send-an-email
    //
    @IBAction func sendSummaryClicked(sender: AnyObject)
    {
        let userDefaults = NSUserDefaults.standardUserDefaults()
        let userEmail = userDefaults.stringForKey("user_email")
        //if the ability to send mail exists
        if (MFMailComposeViewController.canSendMail())
        {
            //create summary
            var emailBody = "Hello, caretaker! I used the force today with my app! Today I learned: \n"
            var index = 0
            var emptyCount = 0
            for con in content {
                if (checked[index] == true)
                {
                    emailBody += " \(con.name) /n"
                    emptyCount += 1
                }
                index += 1
            }
            //if they didnt visit any pages
            if (emptyCount == 0)
            {
                emailBody += "I didn't learn anything today :< \n"
            }
            emailBody += "Thank you for reading!"
            
            //set corresponding info
            mailViewController.setToRecipients([userEmail!])
            mailViewController.setMessageBody(emailBody, isHTML: false)
            mailViewController.setSubject("Learn the Ways of the Force App Summarry")
            presentViewController(mailViewController, animated: true, completion: nil)
        }
        
    }
   
    
    
}

